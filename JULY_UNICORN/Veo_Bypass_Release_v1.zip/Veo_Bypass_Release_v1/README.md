# Veo Standalone Bypass CLI
**Version 1.0** | Created by RenderWithoutCode.com

This utility is designed to bypass the mid-July 2026 Google Flow backend rewriter bugs. By executing your XML constraint cages locally and passing `enhancePrompt: False` directly to the Vertex API, this script prevents character identity drift, architectural morphing, and the dreaded "Unusual Activity" frontend crash.

## Prerequisites
- Python 3.8+
- The `requests` library (`pip install requests`)
- A Google Cloud Vertex AI API Token (Bearer Token)

## Installation
1. Extract this folder to your machine.
2. Open a terminal (PowerShell, Bash, or Command Prompt) inside this folder.
3. Install the required requests library if you don't have it:
   ```bash
   pip install requests
   ```

## Authorization Setup
You MUST set your Vertex API token as an environment variable before running the script. Do not hardcode it.

**Windows (PowerShell):**
```powershell
$env:VERTEX_API_TOKEN="your_vertex_bearer_token"
```

**macOS/Linux (Terminal):**
```bash
export VERTEX_API_TOKEN="your_vertex_bearer_token"
```

## How to Run
We have included a `sample_scene.xml` file which contains a highly-optimized structural constraint cage (The "Helmet Paradigm"). You can run this immediately to test your connection.

**Basic Execution:**
```bash
python veo_standalone_bypass.py --file sample_scene.xml
```

**Custom Output Log:**
If you want to save the raw JSON response (which contains your Job ID and rendering metadata) to a specific file:
```bash
python veo_standalone_bypass.py --file sample_scene.xml --output my_render_log.json
```

## Need Help?
Check out the full breakdown and video case study at **[RenderWithoutCode.com](https://renderwithoutcode.com)**.
