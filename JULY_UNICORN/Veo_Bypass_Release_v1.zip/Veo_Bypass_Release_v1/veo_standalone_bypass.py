#!/usr/bin/env python3
"""
Veo Standalone Bypass CLI Tool
------------------------------
An open-source SRE utility designed to execute un-nested XML constraint cages 
on the Google Cloud Vertex / Veo 3.1 video architecture. 

This utility explicitly forces 'enhancePrompt: False' to bypass the mid-July 2026
backend prompt rewriter layer, preventing character identity drift and 
frontend 'unusual activity' formatting panics.

Usage:
    export VERTEX_API_TOKEN="your_bearer_token_here"
    python veo_standalone_bypass.py --file scene_01.xml --output log.json
"""

import os
import sys
import json
import argparse
import requests

def setup_cli_arguments():
    """Configures and parses command-line arguments for the utility."""
    parser = argparse.ArgumentParser(
        description="Bypass Google Flow's overactive frontend rewriter and force direct XML payload injection."
    )
    
    # Mutually exclusive group: Force user to provide either a file path or a raw string
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "-f", "--file", 
        help="Path to the local .xml file containing your structured constraint cage."
    )
    group.add_argument(
        "-t", "--text", 
        help="Direct string prompt input (Recommended only for brief, single-line testing)."
    )
    
    # Configuration parameters
    parser.add_argument(
        "-o", "--output", 
        default=None,
        help="Optional customized path to save the raw API JSON response log."
    )
    parser.add_argument(
        "--project", 
        default="renderwithoutcode",
        help="Your Google Cloud Project ID. Defaults to 'renderwithoutcode'."
    )
    parser.add_argument(
        "--location", 
        default="us-central1",
        help="GCP Vertex AI deployment location region. Defaults to 'us-central1'."
    )
    
    return parser.parse_args()

def load_prompt_payload(args):
    """Extracts the prompt string based on the user's chosen CLI flags."""
    if args.file:
        if not os.path.exists(args.file):
            print(f"❌ CLI Error: Input file not found at path: {args.file}")
            sys.exit(1)
        try:
            with open(args.file, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            print(f"❌ File Access Error: Unable to read file encoding. Details: {e}")
            sys.exit(1)
    return args.text

def execute_bypass_inference():
    # 1. Parse configuration flags
    args = setup_cli_arguments()
    prompt_data = load_prompt_payload(args)
    
    # 2. Credential Verification (Enforcing Zero-Hardcoding Standards)
    api_token = os.getenv("VERTEX_API_TOKEN")
    if not api_token:
        print("❌ Authentication Error: VERTEX_API_TOKEN environment variable is missing.")
        print("👉 Please set it in your terminal prior to running:")
        print("   Windows (PowerShell): $env:VERTEX_API_TOKEN=\"your_token\"")
        print("   Linux/macOS (Bash):   export VERTEX_API_TOKEN=\"your_token\"")
        sys.exit(1)
        
    # 3. Target Endpoint Construction
    url = f"https://{args.location}-aiplatform.googleapis.com/v1/projects/{args.project}/locations/{args.location}/publishers/google/models/veo-3.1-generate-video:predict"
    
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Content-Type": "application/json; charset=utf-8"
    }
    
    # 4. Strict Structural JSON Payload Setup
    payload = {
        "instances": [
            {
                "prompt": prompt_data
            }
        ],
        "parameters": {
            # THE CORE WORKAROUND: Forcing the backend to drop the automated LLM rewriter pass
            "enhancePrompt": False,
            "aspectRatio": "16:9",
            "frameRate": 24,
            "durationSeconds": 8
        }
    }
    
    # 5. Transmission & Forensic Diagnostic Error Handling
    print(f"📡 Transmitting payload directly to {args.location} Vertex Engine...")
    print("🔒 Parameter Lock Enabled: [enhancePrompt = False]")
    
    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload, ensure_ascii=False))
        
        # Friendly error messages for common server responses
        if response.status_code == 401:
            print("❌ Server Refusal [401]: Invalid or expired Bearer Token. Check your environment variable.")
            sys.exit(1)
        elif response.status_code == 403:
            print("❌ Server Refusal [403]: Permission Denied. Ensure Veo 3.1 API access is enabled on your GCP console.")
            sys.exit(1)
        elif response.status_code == 429:
            print("❌ Server Pressure [429]: Rate limit or concurrent generation limit reached. Cool down your pipeline loop.")
            sys.exit(1)
            
        # Catch any other non-200 HTTP statuses
        response.raise_for_status()
        
    except requests.exceptions.RequestException as e:
        print(f"💥 Network Pipeline Exception: Connection failed or timed out.")
        print(f"📝 Diagnostic Log: {e}")
        if response is not None:
            print(f"📑 Raw Response Context: {response.text}")
        sys.exit(1)
        
    # 6. Output Processing
    response_json = response.json()
    print("\n✅ Pipeline Transmission Success! Payload bypassed cloud processing completely.")
    
    # Extract structural identifiers if present in standard format
    try:
        job_id = response_json.get("prediction", {}).get("job_id", "UNKNOWN_JOB_ID")
        print(f"🆔 Generated Vertex Video Job ID: {job_id}")
    except AttributeError:
        print("ℹ️ Note: Response structure parsed cleanly but did not match standard cloud prediction wrappers.")
        
    # Determine save path for data files
    output_filename = args.output if args.output else f"veo_response_log.json"
    
    try:
        with open(output_filename, "w", encoding="utf-8") as out_file:
            json.dump(response_json, out_file, indent=2, ensure_ascii=False)
        print(f"💾 Raw backend metadata payload safely indexed at: ./{output_filename}")
    except Exception as e:
        print(f"⚠️ Warning: Response received, but script failed to write disk logs. Details: {e}")

if __name__ == "__main__":
    # Ensure standard terminal streams parse unicode characters without throwing environment crashes
    if sys.platform.startswith("win"):
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    execute_bypass_inference()
